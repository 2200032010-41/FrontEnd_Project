import React, { useState } from 'react';
import './EmployerJobPostForm.css';

const EmployerJobPostForm = () => {
  const [job, setJob] = useState({
    title: '',
    description: '',
    company: '',
    location: '',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setJob({ ...job, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await fetch('/api/employer/jobs', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(job),
      });

      if (response.ok) {
        alert('Job posted successfully!');
        setJob({ title: '', description: '', company: '', location: '' });
      } else {
        alert('Failed to post job.');
      }
    } catch (error) {
      console.error('Error posting job:', error);
      alert('An error occurred while posting the job.');
    }
  };

  return (
    <div className="job-post-form">
      <h1>Post a New Job</h1>
      <form onSubmit={handleSubmit}>
        <label>
          Job Title:
          <input
            type="text"
            name="title"
            value={job.title}
            onChange={handleChange}
            required
          />
        </label>
        <label>
          Description:
          <textarea
            name="description"
            value={job.description}
            onChange={handleChange}
            required
          />
        </label>
        <label>
          Company:
          <input
            type="text"
            name="company"
            value={job.company}
            onChange={handleChange}
            required
          />
        </label>
        <label>
          Location:
          <input
            type="text"
            name="location"
            value={job.location}
            onChange={handleChange}
            required
          />
        </label>
        <button type="submit">Post Job</button>
      </form>
    </div>
  );
};

export default EmployerJobPostForm;
