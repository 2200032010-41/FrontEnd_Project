import React, { useState, useEffect } from 'react';
import './AdminDashboard.css'; // Assuming you have some styles for this component

const AdminDashboard = () => {
  // State variables to hold fetched data
  const [placements, setPlacements] = useState([]);
  const [users, setUsers] = useState([]);
  const [jobs, setJobs] = useState([]);

  // useEffect hook to fetch data when the component mounts
  useEffect(() => {
    // Fetching placement records
    fetch('/api/admin/placements')
      .then((res) => res.json())
      .then((data) => setPlacements(data.placements)) // Store the fetched data in state
      .catch((error) => console.error('Error fetching placements:', error)); // Error handling

    // Fetching user records
    fetch('/api/admin/users')
      .then((res) => res.json())
      .then((data) => setUsers(data.users))
      .catch((error) => console.error('Error fetching users:', error));

    // Fetching job records
    fetch('/api/admin/jobs')
      .then((res) => res.json())
      .then((data) => setJobs(data.jobs))
      .catch((error) => console.error('Error fetching jobs:', error));
  }, []); // Empty dependency array ensures this runs only on component mount

  return (
    <div className="admin-dashboard">
      <h1>Admin Dashboard</h1>

      {/* Section for managing users */}
      <section className="dashboard-section">
        <h2>Manage Users</h2>
        <table>
          <thead>
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Role</th>
              <th>Email</th>
            </tr>
          </thead>
          <tbody>
            {users.length > 0 ? (
              users.map((user) => (
                <tr key={user.id}>
                  <td>{user.id}</td>
                  <td>{user.name}</td>
                  <td>{user.role}</td>
                  <td>{user.email}</td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="4">No users found</td>
              </tr>
            )}
          </tbody>
        </table>
      </section>

      {/* Section for managing jobs */}
      <section className="dashboard-section">
        <h2>Manage Jobs</h2>
        <table>
          <thead>
            <tr>
              <th>Job ID</th>
              <th>Title</th>
              <th>Company</th>
              <th>Location</th>
            </tr>
          </thead>
          <tbody>
            {jobs.length > 0 ? (
              jobs.map((job) => (
                <tr key={job.job_id}>
                  <td>{job.job_id}</td>
                  <td>{job.title}</td>
                  <td>{job.company}</td>
                  <td>{job.location}</td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="4">No jobs found</td>
              </tr>
            )}
          </tbody>
        </table>
      </section>

      {/* Section for managing placement records */}
      <section className="dashboard-section">
        <h2>Placement Records</h2>
        <table>
          <thead>
            <tr>
              <th>Student ID</th>
              <th>Job ID</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {placements.length > 0 ? (
              placements.map((placement) => (
                <tr key={placement.placement_id}>
                  <td>{placement.student_id}</td>
                  <td>{placement.job_id}</td>
                  <td>{placement.status}</td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="3">No placements found</td>
              </tr>
            )}
          </tbody>
        </table>
      </section>
    </div>
  );
};

export default AdminDashboard;
