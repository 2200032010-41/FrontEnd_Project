import React from 'react';
import './JobCard.css';

const JobCard = ({ job }) => {
  return (
    <div className="job-card">
      <h3>{job.title}</h3>
      <p><strong>Company:</strong> {job.company}</p>
      <p><strong>Location:</strong> {job.location}</p>
      <p><strong>Eligibility:</strong> {job.eligibility}</p>
      <button className="apply-button">Apply Now</button>
    </div>
  );
};

export default JobCard;
