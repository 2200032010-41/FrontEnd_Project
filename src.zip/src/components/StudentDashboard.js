import React, { useState, useEffect } from 'react';
import JobListings from './JobListings';
import './StudentDashboard.css';

function StudentDashboard() {
  const [appliedJobs, setAppliedJobs] = useState([]);
  const [jobStatus, setJobStatus] = useState(''); // Now we can use this state

  useEffect(() => {
    const fetchAppliedJobs = async () => {
      const jobs = await fetch("/api/student/applied-jobs").then((res) => res.json());
      setAppliedJobs(jobs);
      
      // Simulate setting job status based on the first job's status, for example
      if (jobs.length > 0) {
        setJobStatus(jobs[0].status); // You could do more logic here based on the API response
      }
    };

    fetchAppliedJobs();
  }, []);

  return (
    <div className="student-dashboard">
      <h1>Welcome to your Dashboard</h1>

      <section className="profile-section">
        <h2>Your Profile</h2>
        <p>Edit and manage your resume, skills, and personal information.</p>
        <button>Edit Profile</button>
      </section>

      <section className="applied-jobs-section">
        <h2>Applied Jobs</h2>
        {appliedJobs.length > 0 ? (
          <ul>
            {appliedJobs.map((job) => (
              <li key={job.id}>
                <strong>{job.title}</strong> at {job.company} - Status: {job.status}
              </li>
            ))}
          </ul>
        ) : (
          <p>No jobs applied yet.</p>
        )}

        {/* Display the status of the first applied job */}
        {jobStatus && (
          <p>Current Status of First Applied Job: <strong>{jobStatus}</strong></p>
        )}
      </section>

      <section className="job-listings-section">
        <h2>Explore Jobs</h2>
        <JobListings />
      </section>
    </div>
  );
}

export default StudentDashboard;
