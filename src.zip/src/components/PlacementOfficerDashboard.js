// src/components/PlacementOfficerDashboard.js

import React, { useState } from 'react';
import './PlacementOfficerDashboard.css';

const PlacementOfficerDashboard = () => {
  const [activeTab, setActiveTab] = useState('students');
  const [students, setStudents] = useState([
    { id: 1, name: 'Alice', status: 'Applied' },
    { id: 2, name: 'Bob', status: 'Shortlisted' },
    { id: 3, name: 'Charlie', status: 'Hired' },
  ]);

  const [jobPostings, setJobPostings] = useState([
    { id: 1, title: 'Software Engineer', company: 'ABC Corp', location: 'New York', eligibility: 'CS Graduate' },
    { id: 2, title: 'Data Scientist', company: 'XYZ Ltd', location: 'San Francisco', eligibility: 'Data Science' },
    { id: 3, title: 'Product Manager', company: 'Tech Solutions', location: 'Austin', eligibility: 'MBA' },
  ]);

  const [newJobTitle, setNewJobTitle] = useState('');
  const [newJobCompany, setNewJobCompany] = useState('');

  const handleTabChange = (tab) => {
    setActiveTab(tab);
  };

  const handleAddJob = () => {
    const newJob = {
      id: jobPostings.length + 1,
      title: newJobTitle,
      company: newJobCompany,
      location: 'Location', // You can add more fields as required
      eligibility: 'Eligibility',
    };
    setJobPostings([...jobPostings, newJob]);
    setNewJobTitle('');
    setNewJobCompany('');
  };

  const handleUpdateStatus = (id, newStatus) => {
    const updatedStudents = students.map(student => 
      student.id === id ? { ...student, status: newStatus } : student
    );
    setStudents(updatedStudents);
  };

  return (
    <div className="dashboard">
      <h1>Placement Officer Dashboard</h1>
      <nav className="tab-navigation">
        <button onClick={() => handleTabChange('students')}>Manage Students</button>
        <button onClick={() => handleTabChange('jobPostings')}>Manage Job Postings</button>
      </nav>

      <div className="tab-content">
        {activeTab === 'students' && (
          <div>
            <h2>Manage Students</h2>
            <table>
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Status</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {students.map(student => (
                  <tr key={student.id}>
                    <td>{student.name}</td>
                    <td>{student.status}</td>
                    <td>
                      <button onClick={() => handleUpdateStatus(student.id, 'Hired')}>Hired</button>
                      <button onClick={() => handleUpdateStatus(student.id, 'Rejected')}>Reject</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {activeTab === 'jobPostings' && (
          <div>
            <h2>Manage Job Postings</h2>
            <input
              type="text"
              placeholder="Job Title"
              value={newJobTitle}
              onChange={(e) => setNewJobTitle(e.target.value)}
            />
            <input
              type="text"
              placeholder="Company Name"
              value={newJobCompany}
              onChange={(e) => setNewJobCompany(e.target.value)}
            />
            <button onClick={handleAddJob}>Add Job Posting</button>

            <h3>Current Job Listings</h3>
            <table>
              <thead>
                <tr>
                  <th>Job Title</th>
                  <th>Company</th>
                  <th>Location</th>
                  <th>Eligibility</th>
                </tr>
              </thead>
              <tbody>
                {jobPostings.map(job => (
                  <tr key={job.id}>
                    <td>{job.title}</td>
                    <td>{job.company}</td>
                    <td>{job.location}</td>
                    <td>{job.eligibility}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};

export default PlacementOfficerDashboard;
