import React, { useState, useEffect } from 'react';
import JobCard from './JobCard';
import './JobListings.css';

const JobListings = () => {
  const [jobs, setJobs] = useState([]);  // Holds job data
  const [searchTerm, setSearchTerm] = useState('');  // Holds search input value
  const [filteredJobs, setFilteredJobs] = useState([]);  // Holds filtered job list

  // Mock job data (can be replaced with API call)
  useEffect(() => {
    const mockJobs = [
      { id: 1, title: 'Software Engineer', company: 'ABC Corp', location: 'New York', eligibility: 'CS Graduate' },
      { id: 2, title: 'Data Scientist', company: 'XYZ Ltd', location: 'San Francisco', eligibility: 'Data Science' },
      { id: 3, title: 'Product Manager', company: 'Tech Solutions', location: 'Austin', eligibility: 'MBA' },
    ];
    setJobs(mockJobs);
  }, []);

  // Filter jobs based on search term
  useEffect(() => {
    const filtered = jobs.filter(job =>
      job.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      job.company.toLowerCase().includes(searchTerm.toLowerCase()) ||
      job.location.toLowerCase().includes(searchTerm.toLowerCase())
    );
    setFilteredJobs(filtered);
  }, [searchTerm, jobs]);

  return (
    <div className="job-listings-container">
      <h1>Job Listings</h1>

      {/* Search bar */}
      <input
        type="text"
        placeholder="Search jobs by title, company, or location"
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
        className="search-bar"
      />

      {/* Job cards */}
      <div className="job-list">
        {filteredJobs.length > 0 ? (
          filteredJobs.map((job) => (
            <JobCard key={job.id} job={job} />
          ))
        ) : (
          <p>No jobs found matching your search.</p>
        )}
      </div>
    </div>
  );
};

export default JobListings;
