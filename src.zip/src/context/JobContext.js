// src/context/JobContext.js
import React, { createContext, useState } from 'react';

// Create a Context for job data
export const JobContext = createContext();

export const JobProvider = ({ children }) => {
    const [jobs, setJobs] = useState([]);

    return (
        <JobContext.Provider value={{ jobs, setJobs }}>
            {children}
        </JobContext.Provider>
    );
};
