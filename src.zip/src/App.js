// src/App.js

import React from 'react';
import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { JobProvider } from './context/JobContext'; // Import the JobProvider
import JobListings from './components/JobListings';
import EmployerJobPostForm from './components/EmployerJobPostForm';
import AdminDashboard from './components/AdminDashboard';
import PlacementOfficerDashboard from './components/PlacementOfficerDashboard';
import './App.css';

function App() {
  return (
    <JobProvider>
      <Router>
        <div className="App">
          <Helmet>
            <title>Placement System</title>
          </Helmet>
          <header className="App-header">
            <h1>Placement System</h1>
            <nav>
              <ul>
                <li>
                  <Link to="/job-listings">Job Listings</Link>
                </li>
                <li>
                  <Link to="/post-job">Post a Job</Link>
                </li>
                <li>
                  <Link to="/admin-dashboard">Admin Dashboard</Link>
                </li>
                <li>
                  <Link to="/placement-officer-dashboard">Placement Officer Dashboard</Link>
                </li>
              </ul>
            </nav>
          </header>
          <Routes>
            <Route path="/job-listings" element={<JobListings />} />
            <Route path="/post-job" element={<EmployerJobPostForm />} />
            <Route path="/admin-dashboard" element={<AdminDashboard />} />
            <Route path="/placement-officer-dashboard" element={<PlacementOfficerDashboard />} />
          </Routes>
        </div>
      </Router>
    </JobProvider>
  );
}

export default App;
